Chef Cookbook for Heroku Toolbelt
===============

Very simple cookbook to install Heroku Toolbelt on Ubuntu.

Just include the default recipe and it will run the Heroku installer and add to /etc/profile.d to add the bin directory to the path.

